## run by:
## Rscript --vanilla run.R
## Then point your browser to:
## http://127.0.0.1:7000/

require("shiny")
runApp("demoR",port=7000)
